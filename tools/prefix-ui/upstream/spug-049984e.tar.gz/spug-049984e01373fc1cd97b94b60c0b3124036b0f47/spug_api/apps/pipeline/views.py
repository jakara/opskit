# Copyright: (c) OpenSpug Organization. https://github.com/openspug/spug
# Copyright: (c) <spug.dev@gmail.com>
# Released under the AGPL-3.0 License.
from django.views.generic import View
from django.conf import settings
from django.http.response import HttpResponseBadRequest
from django_redis import get_redis_connection
from libs import JsonParser, Argument, json_response, auth
from libs.utils import AttrDict
from libs.locale import get_request_language
from libs.gitlib import RemoteGit
from apps.pipeline.helper import Helper
from apps.pipeline.models import Pipeline, PipeHistory
from apps.pipeline.utils import NodeExecutor, fill_node_targets
from apps.credential.models import Credential
from threading import Thread
from pathlib import Path
from uuid import uuid4
import copy
import json


class PipeView(View):
    @auth('pipeline.pipeline.view|pipeline.pipeline.edit|pipeline.pipeline.do')
    def get(self, request):
        form, error = JsonParser(
            Argument('id', type=int, required=False)
        ).parse(request.GET)
        if error is None:
            if form.id:
                pipe = Pipeline.objects.filter(pk=form.id).first()
                if not pipe:
                    return json_response(error='未找到指定流程')
                response = pipe.to_view()
            else:
                pipes = list(Pipeline.objects.all())
                latest_map = PipeHistory.latest_map([x.id for x in pipes])
                response = [x.to_list(latest_map.get(x.id)) for x in pipes]
            return json_response(response)
        return json_response(error=error)

    @auth('pipeline.pipeline.add|pipeline.pipeline.edit')
    def post(self, request):
        form, error = JsonParser(
            Argument('id', type=int, required=False),
            Argument('name', help='请输入流程名称'),
            Argument('nodes', type=list, handler=json.dumps, default='[]')
        ).parse(request.body)
        if error is None:
            if form.id:
                Pipeline.objects.filter(pk=form.id).update(**form)
                pipe = Pipeline.objects.get(pk=form.id)
            else:
                pipe = Pipeline.objects.create(created_by=request.user, **form)
            return json_response(pipe.to_view())
        return json_response(error=error)

    @auth('pipeline.pipeline.edit')
    def patch(self, request):
        form, error = JsonParser(
            Argument('id', type=int, help='请指定操作对象'),
            Argument('name', required=False),
            Argument('nodes', type=list, handler=json.dumps, required=False),
        ).parse(request.body, True)
        if error is None:
            Pipeline.objects.filter(pk=form.id).update(**form)
        return json_response(error=error)

    @auth('pipeline.pipeline.del')
    def delete(self, request):
        form, error = JsonParser(
            Argument('id', type=int, help='请指定操作对象')
        ).parse(request.GET)
        if error is None:
            # 逐条删除而不是 queryset.delete()，后者不会触发执行记录的输出文件清理
            pipe = Pipeline.objects.filter(pk=form.id).first()
            if pipe:
                pipe.delete()
        return json_response(error=error)


class DoView(View):
    @auth('pipeline.pipeline.do')
    def post(self, request):
        form, error = JsonParser(
            Argument('id', type=int, help='参数错误'),
        ).parse(request.body)
        if error is None:
            pipe = Pipeline.objects.get(pk=form.id)
            nodes = fill_node_targets(json.loads(pipe.nodes))

            dynamic_params = []
            for item in nodes:
                if item.get('module') == 'parameter':
                    if item.get('dynamic_params'):
                        dynamic_params.extend(item['dynamic_params'])
                elif item.get('module') == 'build':
                    if item.get('git_mode') == 'tag':
                        if item.get('git_tag') == 'selective':
                            credential = None
                            if item.get('credential_id'):
                                credential = Credential.objects.filter(pk=item['credential_id']).first()
                            is_pass, tags = RemoteGit.fetch_remote_tags(item.get('git_url'), credential)
                            if is_pass and tags:
                                options = [{'value': x, 'label': x} for x in tags]
                                dynamic_params.append(
                                    {'variable': '_spug_git_tag', 'name': 'Git标签', 'type': 'select',
                                     'options': options, 'required': True})
                            else:
                                dynamic_params.append(
                                    {'variable': '_spug_git_tag', 'name': 'Git标签', 'type': 'text',
                                     'required': True, 'help': '请输入要构建的Git标签名称'})
                    elif item.get('git_commit') == 'selective':
                        dynamic_params.append(
                            {'variable': '_spug_git_commit', 'name': 'Git Commit', 'type': 'text', 'required': False,
                             'help': '要构建的Commit ID，留空则使用所选分支的最新提交'})
                elif item.get('module') == 'data_upload':
                    tmp = {'variable': item['id'], 'name': item['name'], 'type': 'upload', 'required': True}
                    if item.get('accept'):
                        tmp['accept'] = item['accept']
                    if item.get('size'):
                        tmp['size'] = item['size']
                    dynamic_params.append(tmp)

            token = uuid4().hex
            if dynamic_params:
                response = AttrDict(token=token, nodes=nodes, dynamic_params=dynamic_params)
            else:
                record = PipeHistory.make(pipe, nodes, request.user, token)
                rds = get_redis_connection()
                executor = NodeExecutor(rds, token, json.loads(pipe.nodes), pipe_name=pipe.name,
                                        language=get_request_language(request), history_id=record.id)
                Thread(target=executor.run).start()
                response = AttrDict(token=token, nodes=nodes)
            return json_response(response)
        return json_response(error=error)

    @auth('pipeline.pipeline.do')
    def patch(self, request):
        form, error = JsonParser(
            Argument('id', type=int, help='参数错误'),
            Argument('token', help='参数错误'),
            Argument('params', type=dict, help='参数错误'),
        ).parse(request.body)
        if error is None:
            for k, v in form.params.items():
                if isinstance(v, list):
                    form.params[k] = ','.join(str(x) for x in v)
            pipe = Pipeline.objects.get(pk=form.id)
            nodes = json.loads(pipe.nodes)
            for item in nodes:
                if item.get('module') == 'parameter':
                    item['dynamic_params'] = form.params
                    break

            # 快照要带上 _targets 和本次代入的参数，否则历史控制台还原不出主机分页
            record = PipeHistory.make(pipe, fill_node_targets(copy.deepcopy(nodes)), request.user, form.token)
            rds = get_redis_connection()

            executor = NodeExecutor(rds, form.token, nodes, form.params, pipe_name=pipe.name,
                                    language=get_request_language(request), history_id=record.id)
            Thread(target=executor.run).start()
            return json_response()
        return json_response(error=error)


class HistoryView(View):
    @auth('pipeline.pipeline.view|pipeline.pipeline.edit|pipeline.pipeline.do')
    def get(self, request, h_id=None):
        if h_id:
            record = PipeHistory.objects.filter(pk=h_id).first()
            if not record:
                return json_response(error='未找到指定执行记录')
            self._sync_interrupted([record])
            nodes = json.loads(record.nodes)
            outputs = {}
            for item in nodes:
                # 键的构造必须和执行器一致：节点本身用 id，多主机节点再按 id.主机id 分流
                outputs[item['id']] = {'data': '', 'status': ''}
                for host in item.get('_targets') or []:
                    outputs[f'{item["id"]}.{host["id"]}'] = {'data': '', 'status': ''}

            response = AttrDict(record.to_list())
            response.token = record.token
            response.nodes = nodes
            response.outputs = outputs
            # index 是已消费的消息数，执行中的记录据此接着 websocket 往下收
            response.index = Helper.fill_outputs(outputs, record.token) if record.token else 0
            return json_response(response)

        form, error = JsonParser(
            Argument('pipeline_id', type=int, help='请指定流水线')
        ).parse(request.GET)
        if error is None:
            records = list(PipeHistory.objects.filter(pipeline_id=form.pipeline_id))
            self._sync_interrupted(records)
            return json_response([x.to_list() for x in records])
        return json_response(error=error)

    @auth('pipeline.pipeline.del')
    def delete(self, request, h_id=None):
        record = PipeHistory.objects.filter(pk=h_id).first()
        if record:
            record.delete()
        return json_response()

    @staticmethod
    def _sync_interrupted(records):
        """把不可能再有结果的执行中记录收敛成已中断。

        两种情况：输出键已消失（进程重启等原因让执行线程中途没了）；以及升级前遗留的
        记录——它们没有 token，本就没有输出可回放。迁移文件不随仓库发布（migrations/ 被
        忽略，安装时才 makemigrations），所以只能在这里兜底而不是写数据迁移。
        """
        running = [x for x in records if x.status == 0]
        if not running:
            return
        rds = get_redis_connection()
        for item in running:
            if item.token and rds.exists(item.token):
                continue
            if PipeHistory.objects.filter(pk=item.id, status=0).update(status=3):
                item.status = 3


@auth('pipeline.pipeline.do')
def handle_data_upload(request):
    token = request.POST.get('token')
    node_id = request.POST.get('id')
    file = request.FILES.get('file')
    if not all([token, node_id, file]):
        return HttpResponseBadRequest('参数错误')

    file_path = Path(settings.TRANSFER_DIR) / token / node_id / file.name
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, 'wb') as f:
        for chunk in file.chunks():
            f.write(chunk)
    return json_response('ok')
